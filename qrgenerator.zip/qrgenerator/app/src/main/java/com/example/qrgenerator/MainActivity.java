package com.example.qrgenerator;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class MainActivity extends AppCompatActivity {

    EditText inputText;
    ImageView qrImage;
    Button btnGenerate, btnSave, btnShare;

    Bitmap qrBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputText = findViewById(R.id.inputText);
        qrImage = findViewById(R.id.qrImage);
        btnGenerate = findViewById(R.id.btnGenerate);
        btnSave = findViewById(R.id.btnSave);
        btnShare = findViewById(R.id.btnShare);

        btnGenerate.setOnClickListener(v -> generateQR());

        btnSave.setOnClickListener(v -> saveImage());

        btnShare.setOnClickListener(v -> shareImage());
    }

    private void generateQR() {
        String text = inputText.getText().toString();

        if (text.isEmpty()) {
            Toast.makeText(this, "Enter text or URL", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            BarcodeEncoder encoder = new BarcodeEncoder();
            qrBitmap = encoder.encodeBitmap(text, BarcodeFormat.QR_CODE, 600, 600);
            qrImage.setImageBitmap(qrBitmap);
        } catch (Exception e) {
            Toast.makeText(this, "QR generation failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveImage() {
        if (qrBitmap == null) {
            Toast.makeText(this, "Generate QR first", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            String path = MediaStore.Images.Media.insertImage(
                    getContentResolver(),
                    qrBitmap,
                    "QR_Code",
                    "Generated QR Code"
            );

            Toast.makeText(this, "Saved to Gallery", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void shareImage() {
        try {
            String path = MediaStore.Images.Media.insertImage(
                    getContentResolver(),
                    qrBitmap,
                    "QR_Code",
                    null
            );

            Uri uri = Uri.parse(path);

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.setType("image/png");

            startActivity(Intent.createChooser(intent, "Share QR Code"));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}